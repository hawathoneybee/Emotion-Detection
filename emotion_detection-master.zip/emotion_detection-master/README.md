# emotion_detection
Automate detection of different emotions from textual comments and feedback
